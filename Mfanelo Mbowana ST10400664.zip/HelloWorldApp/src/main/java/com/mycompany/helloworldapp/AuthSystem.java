/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author RC_Student_lab
 */
package com.mycompany.helloworldapp;

import java.util.Scanner;

public class AuthSystem {
    private static User registeredUser;

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            // Registration
            System.out.print("Enter username: ");
            String username = scanner.nextLine();
            if (!Validator.isValidUsername(username)) {
                System.out.println("Username is not correctly formatted, please ensure it contains an underscore and is no more than five characters in length.");
                return;
            }
            System.out.println("Username successfully captured.");

            System.out.print("Enter password: ");
            String password = scanner.nextLine();
            if (!Validator.isValidPassword(password)) {
                System.out.println("Password is not correctly formatted; please ensure it has at least 8 characters, a capital letter, a number, and a special character.");
                return;
            }
            System.out.println("Password successfully captured.");

            System.out.print("Enter cell phone number (e.g. +27831234567): ");
            String phone = scanner.nextLine();
            if (!Validator.isValidPhoneNumber(phone)) {
                System.out.println("Cell phone number incorrectly formatted or does not contain international code.");
                return;
            }
            System.out.println("Cell phone number successfully added.");

            registeredUser = new User(username, password, phone);

            // Login
            System.out.println("\n--- Login ---");
            System.out.print("Enter username: ");
            String loginUser = scanner.nextLine();
            System.out.print("Enter password: ");
            String loginPass = scanner.nextLine();

            if (registeredUser != null && registeredUser.getUsername().equals(loginUser)
                    && registeredUser.checkPassword(loginPass)) {
                System.out.println("Login successful.");
            } else {
                System.out.println("Login failed. Username or password incorrect.");
            }
        }
    }
}
